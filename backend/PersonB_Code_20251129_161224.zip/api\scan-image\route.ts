import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { image } = body;

    if (!image) {
      return NextResponse.json(
        {
          status: 'WARNING',
          title: 'Missing Image',
          message: 'No image data provided',
          confidence: 0,
        },
        { status: 400 }
      );
    }

    // TODO: Add Groq SDK integration here
    // For now, return mock response
    // Example: const groqResponse = await groq.chat.completions.create({...})

    // Mock AI analysis result
    const mockAnalysis = {
      status: 'DANGER' as const,
      title: 'LỪA ĐẢO!',
      message: 'Phát hiện nội dung đáng ngờ trong hình ảnh. Hình ảnh này có thể chứa thông tin lừa đảo, phishing, hoặc nội dung giả mạo. Vui lòng cẩn thận khi chia sẻ hoặc tin tưởng thông tin từ nguồn này.',
      confidence: 85,
    };

    return NextResponse.json(mockAnalysis);
  } catch (error) {
    console.error('Error in scan-image API:', error);
    return NextResponse.json(
      {
        status: 'DANGER',
        title: 'Error',
        message: 'Failed to process image scan',
        confidence: 0,
      },
      { status: 500 }
    );
  }
}

