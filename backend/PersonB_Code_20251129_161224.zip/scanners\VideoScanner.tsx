'use client';

import { useState, useRef, useCallback } from 'react';
import { Upload, Loader2, Video } from 'lucide-react';
import ResultCard from './ResultCard';

interface ScanResult {
  status: 'DANGER' | 'SAFE' | 'WARNING' | 'INFO';
  title: string;
  message: string;
  confidence: number;
}

export default function VideoScanner() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const extractFrame = useCallback((video: HTMLVideoElement, time: number): Promise<string> => {
    return new Promise((resolve, reject) => {
      const canvas = canvasRef.current;
      if (!canvas) {
        reject(new Error('Canvas not available'));
        return;
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Canvas context not available'));
        return;
      }

      video.currentTime = time;
      
      video.onseeked = () => {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0);
        const base64 = canvas.toDataURL('image/jpeg', 0.8);
        resolve(base64);
      };

      video.onerror = () => {
        reject(new Error('Failed to seek video'));
      };
    });
  }, []);

  const extractFrames = useCallback(async (file: File): Promise<string[]> => {
    return new Promise((resolve, reject) => {
      const video = videoRef.current;
      if (!video) {
        reject(new Error('Video element not available'));
        return;
      }

      const url = URL.createObjectURL(file);
      video.src = url;

      video.onloadedmetadata = async () => {
        try {
          const duration = video.duration;
          const frameTimes = [
            duration * 0.2,  // 20%
            duration * 0.5,  // 50%
            duration * 0.8,  // 80%
          ];

          const frames: string[] = [];
          for (const time of frameTimes) {
            const frame = await extractFrame(video, time);
            frames.push(frame);
          }

          URL.revokeObjectURL(url);
          resolve(frames);
        } catch (error) {
          URL.revokeObjectURL(url);
          reject(error);
        }
      };

      video.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error('Failed to load video'));
      };
    });
  }, [extractFrame]);

  const handleScan = async (file: File) => {
    if (!file.type.includes('video') && !file.name.endsWith('.mp4')) {
      alert('Please upload a video file (.mp4)');
      return;
    }

    setIsLoading(true);
    setResult(null);
    setFileName(file.name);

    try {
      // Extract 3 frames from the video
      const frames = await extractFrames(file);

      // Send frames to API
      const response = await fetch('/api/scan-video', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ frames }),
      });

      const data = await response.json();
      setResult(data);
    } catch (error) {
      console.error('Error scanning video:', error);
      setResult({
        status: 'DANGER',
        title: 'Error',
        message: 'Failed to scan video. Please try again.',
        confidence: 0,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleScan(file);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white mb-2">Video Scanner</h2>
        <p className="text-gray-400 text-sm">
          Upload a video file to detect deepfakes, manipulated content, or suspicious video patterns
        </p>
      </div>

      <div className="border-2 border-gray-700 rounded-lg p-12 text-center">
        <input
          ref={fileInputRef}
          type="file"
          accept="video/mp4,video/*"
          onChange={handleFileInput}
          className="hidden"
        />

        {/* Hidden video and canvas elements for frame extraction */}
        <video ref={videoRef} className="hidden" />
        <canvas ref={canvasRef} className="hidden" />

        {isLoading ? (
          <div className="flex flex-col items-center gap-4">
            <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
            <p className="text-gray-400">Extracting frames and analyzing video...</p>
            {fileName && (
              <p className="text-gray-500 text-sm">Processing: {fileName}</p>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-blue-950/50 flex items-center justify-center">
              <Video className="w-8 h-8 text-blue-400" />
            </div>
            <div>
              <p className="text-white font-medium mb-1">
                Select a video file to scan
              </p>
              <p className="text-gray-500 text-sm">
                Supports: MP4 (will extract frames at 20%, 50%, 80%)
              </p>
            </div>
            <div className="mt-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                <Upload className="w-4 h-4" />
                Select Video File
              </button>
            </div>
          </div>
        )}
      </div>

      {result && <ResultCard result={result} />}
    </div>
  );
}

