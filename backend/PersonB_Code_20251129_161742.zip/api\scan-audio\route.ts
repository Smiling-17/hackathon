import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const audioFile = formData.get('audio') as File | null;

    if (!audioFile || !(audioFile instanceof File)) {
      return NextResponse.json(
        {
          status: 'WARNING',
          title: 'Missing Audio',
          message: 'No audio file provided',
          confidence: 0,
        },
        { status: 400 }
      );
    }

    // Validate file size (max 25MB)
    const maxSize = 25 * 1024 * 1024; // 25MB
    if (audioFile.size > maxSize) {
      return NextResponse.json(
        {
          status: 'WARNING',
          title: 'File Too Large',
          message: 'Audio file is too large. Maximum size is 25MB.',
          confidence: 0,
        },
        { status: 400 }
      );
    }

    // Try to use Groq API if available
    // Note: You'll need to add audio transcription service (e.g., Whisper API, AssemblyAI, etc.)
    // For now, we'll use a mock transcription and analyze it with Groq
    
    try {
      const { analyzeAudioWithGroq } = await import('@/lib/groq');
      
      // TODO: Replace this with actual audio transcription
      // Example: const transcription = await transcribeAudio(audioFile);
      // For now, using mock transcription
      const mockTranscription = `[Audio transcription would go here. 
      In production, integrate with Whisper API, AssemblyAI, or similar service to convert audio to text.]`;
      
      // If you have real transcription, use it:
      // const analysis = await analyzeAudioWithGroq(transcription);
      
      // For now, using mock since we don't have transcription service
      throw new Error('Audio transcription not implemented yet');
    } catch (groqError: any) {
      // If Groq is not available or transcription fails, use mock data
      console.warn('Groq API or transcription not available, using mock data:', groqError.message);
      
      const mockAnalysis = {
        status: 'SAFE' as const,
        title: 'Cuộc gọi bình thường',
        message: 'Không phát hiện dấu hiệu lừa đảo trong đoạn ghi âm. Cuộc gọi có vẻ là một cuộc trò chuyện bình thường. Tuy nhiên, vẫn nên cảnh giác với các yêu cầu về thông tin cá nhân hoặc tài chính.',
        confidence: 72,
      };

      return NextResponse.json(mockAnalysis);
    }
  } catch (error) {
    console.error('Error in scan-audio API:', error);
    return NextResponse.json(
      {
        status: 'DANGER',
        title: 'Error',
        message: 'Failed to process audio scan',
        confidence: 0,
      },
      { status: 500 }
    );
  }
}

