import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { image } = body;

    if (!image || typeof image !== 'string') {
      return NextResponse.json(
        {
          status: 'WARNING',
          title: 'Missing Image',
          message: 'No image data provided',
          confidence: 0,
        },
        { status: 400 }
      );
    }

    // Validate base64 format
    if (!image.startsWith('data:image/')) {
      return NextResponse.json(
        {
          status: 'WARNING',
          title: 'Invalid Image Format',
          message: 'Image must be in base64 data URL format',
          confidence: 0,
        },
        { status: 400 }
      );
    }

    // Validate base64 size (max 10MB)
    const base64Size = (image.length * 3) / 4;
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (base64Size > maxSize) {
      return NextResponse.json(
        {
          status: 'WARNING',
          title: 'Image Too Large',
          message: 'Image file is too large. Maximum size is 10MB.',
          confidence: 0,
        },
        { status: 400 }
      );
    }

    // Try to use Groq API if available, otherwise use mock
    try {
      const { analyzeImageWithGroq } = await import('@/lib/groq');
      const analysis = await analyzeImageWithGroq(image);
      return NextResponse.json(analysis);
    } catch (groqError: any) {
      // If Groq is not available or fails, use mock data
      console.warn('Groq API not available, using mock data:', groqError.message);
      
      const mockAnalysis = {
        status: 'DANGER' as const,
        title: 'LỪA ĐẢO!',
        message: 'Phát hiện nội dung đáng ngờ trong hình ảnh. Hình ảnh này có thể chứa thông tin lừa đảo, phishing, hoặc nội dung giả mạo. Vui lòng cẩn thận khi chia sẻ hoặc tin tưởng thông tin từ nguồn này.',
        confidence: 85,
      };

      return NextResponse.json(mockAnalysis);
    }
  } catch (error) {
    console.error('Error in scan-image API:', error);
    return NextResponse.json(
      {
        status: 'DANGER',
        title: 'Error',
        message: 'Failed to process image scan',
        confidence: 0,
      },
      { status: 500 }
    );
  }
}

