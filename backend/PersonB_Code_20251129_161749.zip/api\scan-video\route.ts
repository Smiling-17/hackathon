import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { frames } = body;

    if (!frames || !Array.isArray(frames) || frames.length === 0) {
      return NextResponse.json(
        {
          status: 'WARNING',
          title: 'Missing Frames',
          message: 'No video frames provided',
          confidence: 0,
        },
        { status: 400 }
      );
    }

    // Validate frames format and size
    for (let i = 0; i < frames.length; i++) {
      const frame = frames[i];
      if (typeof frame !== 'string' || !frame.startsWith('data:image/')) {
        return NextResponse.json(
          {
            status: 'WARNING',
            title: 'Invalid Frame Format',
            message: `Frame ${i + 1} is not in valid base64 image format`,
            confidence: 0,
          },
          { status: 400 }
        );
      }

      // Validate frame size (max 5MB per frame)
      const frameSize = (frame.length * 3) / 4;
      const maxFrameSize = 5 * 1024 * 1024; // 5MB
      if (frameSize > maxFrameSize) {
        return NextResponse.json(
          {
            status: 'WARNING',
            title: 'Frame Too Large',
            message: `Frame ${i + 1} is too large. Maximum size is 5MB per frame.`,
            confidence: 0,
          },
          { status: 400 }
        );
      }
    }

    // Try to use Groq API if available, otherwise use mock
    try {
      const { analyzeVideoFramesWithGroq } = await import('@/lib/groq');
      const analysis = await analyzeVideoFramesWithGroq(frames);
      return NextResponse.json(analysis);
    } catch (groqError: any) {
      // If Groq is not available or fails, use mock data
      console.warn('Groq API not available, using mock data:', groqError.message);
      
      const mockAnalysis = {
        status: 'WARNING' as const,
        title: 'Nghi ngờ Deepfake',
        message: 'Phát hiện một số dấu hiệu có thể cho thấy video đã bị chỉnh sửa hoặc deepfake. Các khung hình cho thấy sự không nhất quán về ánh sáng, biểu cảm khuôn mặt, hoặc chuyển động. Vui lòng xác minh nguồn gốc của video trước khi tin tưởng.',
        confidence: 68,
      };

      return NextResponse.json(mockAnalysis);
    }
  } catch (error) {
    console.error('Error in scan-video API:', error);
    return NextResponse.json(
      {
        status: 'DANGER',
        title: 'Error',
        message: 'Failed to process video scan',
        confidence: 0,
      },
      { status: 500 }
    );
  }
}

