import { NextRequest, NextResponse } from 'next/server';
import {
  validateFileSize,
  validateFileType,
  createErrorResponse,
  logApiRequest,
  logApiError,
} from '@/lib/api-utils';

export async function POST(request: NextRequest) {
  logApiRequest('/api/scan-audio', 'POST');

  try {
    const formData = await request.formData();
    const audioFile = formData.get('audio') as File | null;

    if (!audioFile || !(audioFile instanceof File)) {
      return createErrorResponse('WARNING', 'Missing Audio', 'No audio file provided', 400);
    }

    // Validate file size
    const sizeValidation = validateFileSize(audioFile.size, 25);
    if (!sizeValidation.valid) {
      return createErrorResponse('WARNING', 'File Too Large', sizeValidation.error!, 400);
    }

    // Validate file type
    const typeValidation = validateFileType(
      audioFile.name,
      audioFile.type,
      ['.mp3', '.wav'],
      ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/wave', 'audio/x-wav']
    );
    if (!typeValidation.valid) {
      return createErrorResponse('WARNING', 'Invalid File Type', typeValidation.error!, 400);
    }

    // Use Groq API for audio analysis
    const { analyzeAudioWithGroq, isGroqAvailable } = await import('@/lib/groq');
    
    if (!isGroqAvailable()) {
      return createErrorResponse(
        'WARNING',
        'API Key Missing',
        'Groq API key is not configured. Please set GROQ_API_KEY in .env.local file.',
        503
      );
    }

    try {
      // Convert audio to text using Groq Whisper (if available) or basic transcription
      // For now, we'll extract basic info and analyze
      // TODO: Integrate with Whisper API or Groq's audio transcription when available
      
      // Basic audio analysis - in production, use proper transcription service
      const audioBuffer = await audioFile.arrayBuffer();
      const audioSize = audioFile.size;
      const audioDuration = audioSize / 16000; // Rough estimate (16kHz sample rate)
      
      // For now, create a basic analysis prompt based on file metadata
      const analysisPrompt = `Analyze this phone call audio file for scam indicators.
      File size: ${(audioSize / 1024 / 1024).toFixed(2)}MB
      Estimated duration: ${audioDuration.toFixed(1)}s
      
      Look for common scam patterns in phone calls.`;
      
      // Since we don't have transcription yet, we'll use a simplified analysis
      // In production, integrate with: Whisper API, AssemblyAI, or Groq's audio features
      const mockTranscription = `[Audio file received: ${audioFile.name}, ${(audioSize / 1024 / 1024).toFixed(2)}MB]
      Note: Audio transcription service not yet integrated. 
      Please integrate Whisper API or similar service for full analysis.`;
      
      // Analyze with Groq
      const analysis = await analyzeAudioWithGroq(mockTranscription);
      return NextResponse.json(analysis);
      
    } catch (groqError: any) {
      logApiError('/api/scan-audio', groqError);
      
      return createErrorResponse(
        'DANGER',
        'Analysis Error',
        groqError.message ||
          'Failed to analyze audio with Groq API. Please ensure audio transcription service is configured.',
        500
      );
    }
  } catch (error: any) {
    logApiError('/api/scan-audio', error);
    return createErrorResponse('DANGER', 'Server Error', 'Failed to process audio scan request', 500);
  }
}

