import Groq from 'groq-sdk';

// Initialize Groq client
let groqClient: Groq | null = null;

export function getGroqClient(): Groq {
  const apiKey = process.env.GROQ_API_KEY;
  
  if (!apiKey || !apiKey.startsWith('gsk_')) {
    throw new Error('GROQ_API_KEY is missing or invalid. Please set GROQ_API_KEY in .env.local');
  }

  // Initialize client only once
  if (!groqClient) {
    groqClient = new Groq({
      apiKey: apiKey,
    });
  }

  return groqClient;
}

export function isGroqAvailable(): boolean {
  const apiKey = process.env.GROQ_API_KEY;
  return !!(apiKey && apiKey.startsWith('gsk_'));
}

// Helper function to analyze image with Groq Vision
export async function analyzeImageWithGroq(imageBase64: string): Promise<{
  status: 'DANGER' | 'SAFE' | 'WARNING' | 'INFO';
  title: string;
  message: string;
  confidence: number;
}> {
  const client = getGroqClient();

  try {
    const response = await client.chat.completions.create({
      model: 'llama-3.2-90b-vision-preview',
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: `Analyze this image for scam, phishing, or suspicious content. 
              Respond in Vietnamese with JSON format:
              {
                "status": "DANGER" | "SAFE" | "WARNING" | "INFO",
                "title": "Short title in Vietnamese",
                "message": "Detailed explanation in Vietnamese",
                "confidence": number between 0-100
              }
              
              Focus on:
              - Phishing attempts
              - Scam indicators
              - Suspicious text or patterns
              - Fake content or manipulation`,
            },
            {
              type: 'image_url',
              image_url: {
                url: imageBase64,
              },
            },
          ],
        },
      ],
      temperature: 0.7,
      max_tokens: 500,
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error('No response from Groq');
    }

    // Try to parse JSON from response
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          status: parsed.status || 'WARNING',
          title: parsed.title || 'Phân tích hình ảnh',
          message: parsed.message || content,
          confidence: parsed.confidence || 50,
        };
      }
    } catch (parseError) {
      // If JSON parsing fails, extract info from text
      console.warn('Failed to parse Groq JSON response, using text extraction');
    }

    // Fallback: extract information from text response
    const lowerContent = content.toLowerCase();
    let status: 'DANGER' | 'SAFE' | 'WARNING' | 'INFO' = 'INFO';
    if (lowerContent.includes('lừa đảo') || lowerContent.includes('scam') || lowerContent.includes('phishing')) {
      status = 'DANGER';
    } else if (lowerContent.includes('an toàn') || lowerContent.includes('safe') || lowerContent.includes('bình thường')) {
      status = 'SAFE';
    } else if (lowerContent.includes('cảnh báo') || lowerContent.includes('warning') || lowerContent.includes('nghi ngờ')) {
      status = 'WARNING';
    }

    return {
      status,
      title: status === 'DANGER' ? 'LỪA ĐẢO!' : status === 'WARNING' ? 'Cảnh báo' : 'An toàn',
      message: content,
      confidence: status === 'DANGER' ? 75 : status === 'WARNING' ? 60 : 70,
    };
  } catch (error) {
    console.error('Groq API error:', error);
    throw error;
  }
}

// Helper function to analyze audio transcription with Groq
export async function analyzeAudioWithGroq(transcription: string): Promise<{
  status: 'DANGER' | 'SAFE' | 'WARNING' | 'INFO';
  title: string;
  message: string;
  confidence: number;
}> {
  const client = getGroqClient();

  try {
    const response = await client.chat.completions.create({
      model: 'llama-3.1-70b-versatile',
      messages: [
        {
          role: 'user',
          content: `Analyze this phone call transcription for scam or phishing indicators. 
          Respond in Vietnamese with JSON format:
          {
            "status": "DANGER" | "SAFE" | "WARNING" | "INFO",
            "title": "Short title in Vietnamese",
            "message": "Detailed explanation in Vietnamese",
            "confidence": number between 0-100
          }
          
          Transcription:
          ${transcription}
          
          Look for:
          - Requests for personal information
          - Urgent financial requests
          - Suspicious offers or prizes
          - Threats or pressure tactics
          - Impersonation attempts`,
        },
      ],
      temperature: 0.7,
      max_tokens: 500,
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error('No response from Groq');
    }

    // Try to parse JSON from response
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          status: parsed.status || 'WARNING',
          title: parsed.title || 'Phân tích cuộc gọi',
          message: parsed.message || content,
          confidence: parsed.confidence || 50,
        };
      }
    } catch (parseError) {
      console.warn('Failed to parse Groq JSON response, using text extraction');
    }

    // Fallback: extract information from text
    const lowerContent = content.toLowerCase();
    let status: 'DANGER' | 'SAFE' | 'WARNING' | 'INFO' = 'INFO';
    if (lowerContent.includes('lừa đảo') || lowerContent.includes('scam')) {
      status = 'DANGER';
    } else if (lowerContent.includes('an toàn') || lowerContent.includes('safe')) {
      status = 'SAFE';
    } else if (lowerContent.includes('cảnh báo') || lowerContent.includes('warning')) {
      status = 'WARNING';
    }

    return {
      status,
      title: status === 'DANGER' ? 'Cuộc gọi lừa đảo!' : status === 'WARNING' ? 'Cảnh báo' : 'Cuộc gọi bình thường',
      message: content,
      confidence: status === 'DANGER' ? 80 : status === 'WARNING' ? 65 : 72,
    };
  } catch (error: any) {
    console.error('Groq API error:', error);
    
    if (error?.status === 401) {
      throw new Error('Invalid Groq API key. Please check your GROQ_API_KEY in .env.local');
    }
    if (error?.status === 429) {
      throw new Error('Groq API rate limit exceeded. Please try again later.');
    }
    
    throw new Error(`Groq API error: ${error?.message || 'Unknown error'}`);
  }
}

// Helper function to analyze video frames with Groq Vision
export async function analyzeVideoFramesWithGroq(frames: string[]): Promise<{
  status: 'DANGER' | 'SAFE' | 'WARNING' | 'INFO';
  title: string;
  message: string;
  confidence: number;
}> {
  const client = getGroqClient();

  try {
    // Analyze all frames and combine results
    const analyses = await Promise.all(
      frames.map(async (frame) => {
        const response = await client!.chat.completions.create({
          model: 'llama-3.2-90b-vision-preview',
          messages: [
            {
              role: 'user',
              content: [
                {
                  type: 'text',
                  text: `Analyze this video frame for deepfake, manipulation, or suspicious content indicators.
                  Respond in Vietnamese with JSON format:
                  {
                    "status": "DANGER" | "SAFE" | "WARNING" | "INFO",
                    "indicators": ["list of indicators found"],
                    "confidence": number between 0-100
                  }
                  
                  Look for:
                  - Inconsistent lighting
                  - Unnatural facial expressions
                  - Artifacts or glitches
                  - Suspicious backgrounds
                  - Deepfake indicators`,
                },
                {
                  type: 'image_url',
                  image_url: {
                    url: frame,
                  },
                },
              ],
            },
          ],
          temperature: 0.7,
          max_tokens: 300,
        });

        return response.choices[0]?.message?.content || '';
      })
    );

    // Combine all analyses
    const combinedAnalysis = analyses.join('\n\n');

    // Final analysis of combined results
    const finalResponse = await client.chat.completions.create({
      model: 'llama-3.1-70b-versatile',
      messages: [
        {
          role: 'user',
          content: `Based on these frame analyses, provide a final assessment:
          
          ${combinedAnalysis}
          
          Respond in Vietnamese with JSON format:
          {
            "status": "DANGER" | "SAFE" | "WARNING" | "INFO",
            "title": "Short title in Vietnamese",
            "message": "Detailed explanation in Vietnamese",
            "confidence": number between 0-100
          }`,
        },
      ],
      temperature: 0.7,
      max_tokens: 500,
    });

    const content = finalResponse.choices[0]?.message?.content;
    if (!content) {
      throw new Error('No response from Groq');
    }

    // Try to parse JSON
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          status: parsed.status || 'WARNING',
          title: parsed.title || 'Phân tích video',
          message: parsed.message || content,
          confidence: parsed.confidence || 50,
        };
      }
    } catch (parseError) {
      console.warn('Failed to parse Groq JSON response, using text extraction');
    }

    // Fallback
    const lowerContent = content.toLowerCase();
    let status: 'DANGER' | 'SAFE' | 'WARNING' | 'INFO' = 'WARNING';
    if (lowerContent.includes('deepfake') || lowerContent.includes('giả mạo')) {
      status = 'DANGER';
    } else if (lowerContent.includes('nghi ngờ') || lowerContent.includes('suspicious')) {
      status = 'WARNING';
    } else if (lowerContent.includes('an toàn') || lowerContent.includes('safe')) {
      status = 'SAFE';
    }

    return {
      status,
      title: status === 'DANGER' ? 'Deepfake phát hiện!' : 'Nghi ngờ Deepfake',
      message: content,
      confidence: status === 'DANGER' ? 75 : 68,
    };
  } catch (error: any) {
    console.error('Groq API error:', error);
    
    if (error?.status === 401) {
      throw new Error('Invalid Groq API key. Please check your GROQ_API_KEY in .env.local');
    }
    if (error?.status === 429) {
      throw new Error('Groq API rate limit exceeded. Please try again later.');
    }
    if (error?.status === 400) {
      throw new Error('Invalid request to Groq API. Please check your input.');
    }
    
    throw new Error(`Groq API error: ${error?.message || 'Unknown error'}`);
  }
}

